package com.example.beenthere

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.beenthere.ui.theme.BeenThereTheme

/**
 * Main activity for the Been There app. Displays a list of cafes and provides
 * options to add or edit cafes.
 */
class MainActivity : ComponentActivity() {

    private lateinit var dbHelper: DatabaseHelper

    /**
     * Launcher for the AddCafeActivity. Updates the cafe list when a new cafe is added.
     */
    private val addCafeLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            // Fetch the cafe data from the database after addition
            cafeList = dbHelper.getAllCafes()
        }
    }

    /**
     * Launcher for the EditCafeActivity. Updates the cafe list when a cafe is edited or deleted.
     */
    private val editCafeLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            // Fetch the cafe data from the database after edits or deletions
            cafeList = dbHelper.getAllCafes()
        }
    }

    private var cafeList by mutableStateOf(listOf<Cafe>())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dbHelper = DatabaseHelper(this)
        dbHelper.insertDefaultCafes()
        cafeList = dbHelper.getAllCafes()
        setContent {
            BeenThereTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CafeListScreen(
                        cafeList = cafeList,
                        onAddClick = {
                            val intent = Intent(this, AddCafeActivity::class.java)
                            addCafeLauncher.launch(intent)
                        },
                        onCafeClick = { cafe ->
                            val intent = Intent(this, ViewDetailActivity::class.java)
                            intent.putExtra("cafeName", cafe.name)
                            editCafeLauncher.launch(intent)
                        },
                        onSortClick = {
                            cafeList = cafeList.sortedByDescending { it.rating }
                        }
                    )
                }
            }
        }
    }
}

/**
 * Composable function to display the list of cafes.
 *
 * @param cafeList List of cafes to display.
 * @param onAddClick Lambda function to handle the add button click event.
 * @param onCafeClick Lambda function to handle cafe item click events.
 * @param onSortClick Lambda function to handle the sort button click event.
 */
@Composable
fun CafeListScreen(cafeList: List<Cafe>, onAddClick: () -> Unit, onCafeClick: (Cafe) -> Unit, onSortClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .border(10.dp, Color(0xFF4B6F4E))
            .background(Color(0xFFFFE4E1))
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Been There.",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF800000),
                    fontStyle = FontStyle.Italic,
                    fontSize = 20.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
                IconButton(
                    onClick = onSortClick,
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    Icon(Icons.Filled.List, contentDescription = "Sort by Rating")
                }
            }
            if (cafeList.isEmpty()) {
                Spacer(modifier = Modifier.height(300.dp))
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No café listed yet.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))
                CafeList(cafeList, onCafeClick)
            }
        }

        FloatingActionButton(
            onClick = onAddClick,
            containerColor = Color.Red,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Add")
        }
    }
}

/**
 * Composable function to display a list of cafes.
 *
 * @param cafes List of cafes to display.
 * @param onCafeClick Lambda function to handle cafe item click events.
 */
@Composable
fun CafeList(cafes: List<Cafe>, onCafeClick: (Cafe) -> Unit) {
    Column {
        for (cafe in cafes) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(8.dp)
                    .clickable { onCafeClick(cafe) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = cafe.name, style = MaterialTheme.typography.titleLarge, color = Color.Red)
                    Text(text = "★".repeat(cafe.rating), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

/**
 * Preview function to display the CafeListScreen in the IDE preview.
 */
@Preview(showBackground = true)
@Composable
fun CafeListScreenPreview() {
    BeenThereTheme {
        CafeListScreen(cafeList = listOf(), onAddClick = {}, onCafeClick = {}, onSortClick = {})
    }
}
// 22100259 Mobile Application Development | Final Project
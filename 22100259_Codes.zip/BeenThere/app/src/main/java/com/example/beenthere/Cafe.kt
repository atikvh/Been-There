package com.example.beenthere

data class Cafe(
    val name: String,
    val rating: Int,
    val additionalInfo: String,
    val date: String,
    val time: String,
    val imageUri: String? = null
)
// 22100259 Mobile Application Development | Final Project
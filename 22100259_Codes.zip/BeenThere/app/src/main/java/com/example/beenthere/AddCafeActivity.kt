package com.example.beenthere

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.annotation.ExperimentalCoilApi
import coil.compose.rememberImagePainter
import com.example.beenthere.ui.theme.BeenThereTheme
import java.util.*

/**
 * Activity for adding a new cafe. Handles user input for cafe details and image upload.
 */
class AddCafeActivity : ComponentActivity() {
    private lateinit var selectImageLauncher: ActivityResultLauncher<String>
    private var imageUri by mutableStateOf<String?>(null)
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dbHelper = DatabaseHelper(this)

        selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                imageUri = uri.toString()
            }
        }

        setContent {
            BeenThereTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF3D4D5)
                ) {
                    AddCafeScreen(
                        onAdd = { cafe ->
                            dbHelper.addCafe(cafe)
                            val resultIntent = Intent().putExtra("newCafe", cafe.name)
                            setResult(RESULT_OK, resultIntent)
                            finish()
                        },
                        imageUri = imageUri,
                        onImageUriChange = { uri ->
                            imageUri = uri
                        }
                    )
                }
            }
        }
    }

    /**
     * Composable function to display the add cafe screen.
     *
     * @param onAdd Lambda function to handle adding a new cafe.
     * @param imageUri Current image URI to be displayed.
     * @param onImageUriChange Lambda function to update the image URI.
     */
    @OptIn(ExperimentalCoilApi::class)
    @Composable
    fun AddCafeScreen(onAdd: (Cafe) -> Unit, imageUri: String?, onImageUriChange: (String?) -> Unit) {
        var cafeName by remember { mutableStateOf("") }
        var additionalInfo by remember { mutableStateOf("") }
        var starRating by remember { mutableIntStateOf(0) }
        var date by remember { mutableStateOf("") }
        var time by remember { mutableStateOf("") }
        val context = LocalContext.current
        val calendar = Calendar.getInstance()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(25.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .align(Alignment.TopCenter),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BasicTextField(
                    value = cafeName,
                    onValueChange = { cafeName = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .height(35.dp)
                        .border(1.dp, Color(0xFF4B6F4E))
                        .background(Color.White),
                    textStyle = TextStyle(
                        color = Color.Black,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Start
                    ),
                    decorationBox = { innerTextField ->
                        if (cafeName.isEmpty()) {
                            Text(
                                text = " Place Name",
                                color = Color.LightGray,
                                fontSize = 18.sp
                            )
                        }
                        innerTextField()
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                BasicTextField(
                    value = additionalInfo,
                    onValueChange = { additionalInfo = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .height(300.dp)
                        .border(1.dp, Color(0xFF4B6F4E))
                        .background(Color.White),
                    textStyle = TextStyle(color = Color.Black, fontSize = 18.sp),
                    decorationBox = { innerTextField ->
                        if (additionalInfo.isEmpty()) {
                            Text(
                                text = " How was it?",
                                color = Color.LightGray,
                                fontSize = 18.sp
                            )
                        }
                        innerTextField()
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
                StarRatingInput(rating = starRating, onRatingChange = { starRating = it })
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            try {
                                val datePickerDialog = DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        date = "$dayOfMonth/${month + 1}/$year"
                                    },
                                    calendar.get(Calendar.YEAR),
                                    calendar.get(Calendar.MONTH),
                                    calendar.get(Calendar.DAY_OF_MONTH)
                                )
                                datePickerDialog.show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Error selecting date: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF93C572))
                    ) {
                        Text(text = "Date", color = Color.Black)
                    }
                    Spacer(modifier = Modifier.width(100.dp))
                    Button(
                        onClick = {
                            try {
                                val timePickerDialog = TimePickerDialog(
                                    context,
                                    { _, hourOfDay, minute ->
                                        time = "$hourOfDay:$minute"
                                    },
                                    calendar.get(Calendar.HOUR_OF_DAY),
                                    calendar.get(Calendar.MINUTE),
                                    true
                                )
                                timePickerDialog.show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Error selecting time: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF93C572))
                    ) {
                        Text(text = "Time", color = Color.Black)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        selectImageLauncher.launch("image/*")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006400))
                ) {
                    Text(text = "Upload Image", color = Color.White)
                }
                Spacer(modifier = Modifier.height(16.dp))
                imageUri?.let {
                    Image(
                        painter = rememberImagePainter(it),
                        contentDescription = null,
                        modifier = Modifier
                            .size(200.dp)
                            .align(Alignment.CenterHorizontally)
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Button(
                    onClick = { finish() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                ) {
                    Text(text = "CANCEL", color = Color.Red, fontWeight = FontWeight.ExtraBold)
                }
                Button(
                    onClick = {
                        if (cafeName.isNotEmpty() && starRating > 0) {
                            try {
                                val newCafe = Cafe(
                                    name = cafeName,
                                    rating = starRating,
                                    additionalInfo = additionalInfo,
                                    date = date,
                                    time = time,
                                    imageUri = imageUri
                                )
                                onAdd(newCafe)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Error adding cafe: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(
                                context,
                                "Please give a place name and a rating",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                ) {
                    Text(text = "ADD", color = Color.Black, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }

    /**
     * Composable function to display a star rating input.
     *
     * @param rating Current rating value.
     * @param onRatingChange Lambda function to handle rating change.
     */
    @Composable
    fun StarRatingInput(rating: Int, onRatingChange: (Int) -> Unit) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 1..5) {
                Text(
                    text = if (i <= rating) "★" else "☆",
                    fontSize = 35.sp,
                    color = Color.Yellow,
                    modifier = Modifier
                        .padding(4.dp)
                        .clickable { onRatingChange(i) }
                )
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun AddCafeScreenPreview() {
        BeenThereTheme {
            AddCafeScreen(onAdd = {}, imageUri = null, onImageUriChange = {})
        }
    }
}
// 22100259 Mobile Application Development | Final Project
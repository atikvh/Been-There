package com.example.beenthere

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

/**
 * Helper class for managing the SQLite database for storing and retrieving Cafe records.
 *
 * @param context Application context for accessing shared preferences and database.
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "cafesDatabase.db"
        private const val DATABASE_VERSION = 1
        const val TABLE_NAME = "Places"
        const val COLUMN_NAME = "name"
        const val COLUMN_RATING = "rating"
        const val COLUMN_ADDITIONAL_INFO = "additionalInfo"
        const val COLUMN_DATE = "date"
        const val COLUMN_TIME = "time"
        const val COLUMN_IMAGE_URI = "imageUri"

        private const val PREFS_NAME = "DatabasePrefs"
        private const val PREFS_KEY_INITIALIZED = "isInitialized"
    }

    private val context: Context = context.applicationContext

    /**
     * Creates the database and the table to store cafe records.
     *
     * @param db SQLiteDatabase instance used to execute the SQL commands.
     */
    override fun onCreate(db: SQLiteDatabase?) {
        Log.d("DatabaseHelper", "Creating database and table")
        val createTable = ("CREATE TABLE $TABLE_NAME ("
                + "$COLUMN_NAME TEXT PRIMARY KEY,"
                + "$COLUMN_RATING INTEGER,"
                + "$COLUMN_ADDITIONAL_INFO TEXT,"
                + "$COLUMN_DATE TEXT,"
                + "$COLUMN_TIME TEXT,"
                + "$COLUMN_IMAGE_URI TEXT)")
        db?.execSQL(createTable)
        Log.d("DatabaseHelper", "Table $TABLE_NAME created")
    }

    /**
     * Upgrades the database schema by dropping the existing table and creating a new one.
     *
     * @param db SQLiteDatabase instance used to execute the SQL commands.
     * @param oldVersion Old database version.
     * @param newVersion New database version.
     */
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        Log.d("DatabaseHelper", "Upgrading database from version $oldVersion to $newVersion")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    /**
     * Adds a new Cafe record to the database.
     *
     * @param cafe The Cafe object containing the data to be inserted.
     * @return The row ID of the newly inserted row, or -1 if an error occurred.
     */
    fun addCafe(cafe: Cafe): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, cafe.name)
            put(COLUMN_RATING, cafe.rating)
            put(COLUMN_ADDITIONAL_INFO, cafe.additionalInfo)
            put(COLUMN_DATE, cafe.date)
            put(COLUMN_TIME, cafe.time)
            put(COLUMN_IMAGE_URI, cafe.imageUri)
        }
        val result = db.insert(TABLE_NAME, null, values)
        db.close()
        return result
    }

    /**
     * Updates an existing Cafe record in the database.
     *
     * @param cafe The Cafe object containing updated data.
     * @return The number of rows affected.
     */
    fun updateCafe(cafe: Cafe): Int {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_RATING, cafe.rating)
            put(COLUMN_ADDITIONAL_INFO, cafe.additionalInfo)
            put(COLUMN_DATE, cafe.date)
            put(COLUMN_TIME, cafe.time)
            put(COLUMN_IMAGE_URI, cafe.imageUri)
        }
        // Use the name to identify which record to update
        val result = db.update(TABLE_NAME, values, "$COLUMN_NAME=?", arrayOf(cafe.name))
        db.close()
        return result
    }

    /**
     * Deletes a Cafe record from the database.
     *
     * @param cafe The Cafe object to be deleted.
     * @return The number of rows affected.
     */
    fun deleteCafe(cafe: Cafe): Int {
        val db = this.writableDatabase
        // Use the name to identify which record to delete
        val result = db.delete(TABLE_NAME, "$COLUMN_NAME=?", arrayOf(cafe.name))
        db.close()
        return result
    }

    /**
     * Retrieves all Cafe records from the database.
     *
     * @return A list of Cafe objects representing all records in the database.
     */
    fun getAllCafes(): List<Cafe> {
        val cafes = mutableListOf<Cafe>()
        val db = this.readableDatabase
        val cursor = db.query(TABLE_NAME, null, null, null, null, null, null)
        if (cursor.moveToFirst()) {
            do {
                val cafe = Cafe(
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    rating = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_RATING)),
                    additionalInfo = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ADDITIONAL_INFO)),
                    date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)),
                    time = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIME)),
                    imageUri = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE_URI))
                )
                cafes.add(cafe)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return cafes
    }

    /**
     * Retrieves a single Cafe record by its name.
     *
     * @param name The name of the cafe to be retrieved.
     * @return The Cafe object if found, or null if no matching record was found.
     */
    fun getCafeByName(name: String): Cafe? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_NAME,
            null,
            "$COLUMN_NAME=?",
            arrayOf(name),
            null,
            null,
            null
        )
        val cafe: Cafe? = if (cursor.moveToFirst()) {
            Cafe(
                name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                rating = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_RATING)),
                additionalInfo = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ADDITIONAL_INFO)),
                date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)),
                time = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIME)),
                imageUri = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE_URI))
            )
        } else {
            null
        }
        cursor.close()
        db.close()
        return cafe
    }


    /**
     * Inserts default Cafe records if the database is being used for the first time.
     */
    fun insertDefaultCafes() {
        if (isFirstRun()) {
            val db = this.writableDatabase
            val values = ContentValues().apply {
                put(COLUMN_NAME, "Name of cafe")
                put(COLUMN_RATING, 5)
                put(COLUMN_ADDITIONAL_INFO, "What did you think about it?")
                put(COLUMN_DATE, "2024-01-01")
                put(COLUMN_TIME, "12:00 PM")
                put(COLUMN_IMAGE_URI, "")
            }
            db.insert(TABLE_NAME, null, values)
            setInitialized()
            db.close()
        }
    }

    /**
     * Checks if the database is being used for the first time by checking shared preferences.
     *
     * @return True if this is the first run, false otherwise.
     */
    private fun isFirstRun(): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return !prefs.getBoolean(PREFS_KEY_INITIALIZED, false)
    }

    /**
     * Marks the database as initialized in shared preferences.
     */
    private fun setInitialized() {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putBoolean(PREFS_KEY_INITIALIZED, true)
            apply()
        }
    }
}
// 22100259 Mobile Application Development | Final Project
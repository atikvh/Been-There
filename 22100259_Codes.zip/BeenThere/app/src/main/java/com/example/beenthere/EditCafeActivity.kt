package com.example.beenthere

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.annotation.ExperimentalCoilApi
import coil.compose.rememberImagePainter
import com.example.beenthere.ui.theme.BeenThereTheme
import java.util.*

/**
 * Activity for editing an existing cafe entry.
 * Allows updating details such as additional info, rating, date, time, and image.
 */
class EditCafeActivity : ComponentActivity() {
    private lateinit var selectImageLauncher: ActivityResultLauncher<String>
    private var imageUri by mutableStateOf<String?>(null)
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dbHelper = DatabaseHelper(this)

        selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                imageUri = uri.toString()
            }
        }

        // Retrieve cafe Name from intent and load cafe details from the database
        val cafeName = intent.getStringExtra("cafeName") ?: ""
        val cafe = dbHelper.getCafeByName(cafeName)

        // Initialize imageUri with the cafe's existing imageUri
        imageUri = cafe?.imageUri

        setContent {
            BeenThereTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF3D4D5)
                ) {
                    if (cafe != null) {
                        EditCafeScreen(
                            cafe = cafe,
                            onEdit = { updatedCafe ->
                                dbHelper.updateCafe(updatedCafe)
                                val resultIntent = Intent().putExtra("updatedCafeName", updatedCafe.name)
                                setResult(RESULT_OK, resultIntent)
                                finish()
                            },
                            imageUri = imageUri,
                            onImageUriChange = { uri ->
                                imageUri = uri
                            }
                        )
                    }
                }
            }
        }
    }

    /**
     * Composable function to display the edit cafe screen.
     *
     * @param cafe The cafe object to be edited.
     * @param onEdit Lambda function to handle the edit operation.
     * @param imageUri Current image URI.
     * @param onImageUriChange Lambda function to update the image URI.
     */
    @OptIn(ExperimentalCoilApi::class)
    @Composable
    fun EditCafeScreen(cafe: Cafe, onEdit: (Cafe) -> Unit, imageUri: String?, onImageUriChange: (String?) -> Unit) {
        var additionalInfo by remember { mutableStateOf(cafe.additionalInfo) }
        var starRating by remember { mutableIntStateOf(cafe.rating) }
        var date by remember { mutableStateOf(cafe.date) }
        var time by remember { mutableStateOf(cafe.time) }
        val context = LocalContext.current
        val calendar = Calendar.getInstance()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(25.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = cafe.name,
                    style = TextStyle(
                        fontSize = 35.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF800000),
                        fontStyle = FontStyle.Italic
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    textAlign = TextAlign.Center
                )
                BasicTextField(
                    value = additionalInfo,
                    onValueChange = { additionalInfo = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .height(200.dp)
                        .padding(16.dp),
                    textStyle = TextStyle(
                        color = Color.Black,
                        fontSize = 18.sp
                    ),
                    decorationBox = { innerTextField ->
                        if (additionalInfo.isEmpty()) {
                            Text(
                                text = "Notes",
                                color = Color.LightGray,
                                fontSize = 18.sp
                            )
                        }
                        innerTextField()
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Rating:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                StarRatingInput(rating = starRating, onRatingChange = { starRating = it })
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            val datePickerDialog = DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    date = "$dayOfMonth/${month + 1}/$year"
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            )
                            datePickerDialog.show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF93C572))
                    ) {
                        Text(text = "Date", color = Color.Black)
                    }
                    Spacer(modifier = Modifier.width(100.dp))
                    Button(
                        onClick = {
                            val timePickerDialog = TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    time = "$hourOfDay:$minute"
                                },
                                calendar.get(Calendar.HOUR_OF_DAY),
                                calendar.get(Calendar.MINUTE),
                                true
                            )
                            timePickerDialog.show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF93C572))
                    ) {
                        Text(text = "Time", color = Color.Black)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        selectImageLauncher.launch("image/*")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006400))
                ) {
                    Text(text = "Upload Image", color = Color.White)
                }
                Spacer(modifier = Modifier.height(16.dp))
                imageUri?.let {
                    Image(
                        painter = rememberImagePainter(it),
                        contentDescription = null,
                        modifier = Modifier
                            .size(200.dp)
                            .align(Alignment.CenterHorizontally)
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Button(
                    onClick = {
                        finish()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                ) {
                    Text("CANCEL", color = Color.Red, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = {
                        if (starRating > 0) {
                            val updatedCafe = Cafe(
                                name = cafe.name,
                                rating = starRating,
                                additionalInfo = additionalInfo,
                                date = date,
                                time = time,
                                imageUri = imageUri // Use the existing imageUri if no new image was selected
                            )
                            onEdit(updatedCafe)
                        } else {
                            Toast.makeText(context, "Please fill in completely!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                ) {
                    Text("SAVE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    /**
     * Composable function to display a star rating input.
     *
     * @param rating Current rating value.
     * @param onRatingChange Lambda function to handle rating change.
     */
    @Composable
    fun StarRatingInput(rating: Int, onRatingChange: (Int) -> Unit) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 1..5) {
                Text(
                    text = if (i <= rating) "★" else "☆",
                    fontSize = 35.sp,
                    color = Color.Yellow,
                    modifier = Modifier
                        .padding(4.dp)
                        .clickable { onRatingChange(i) }
                )
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun EditCafeScreenPreview() {
        BeenThereTheme {
            val cafe = Cafe(
                name = "Cafe Mocha",
                rating = 4,
                additionalInfo = "A lovely cafe with great ambiance.",
                date = "01/08/2024",
                time = "10:30 AM",
                imageUri = null
            )
            EditCafeScreen(
                cafe = cafe,
                onEdit = {},
                imageUri = null,
                onImageUriChange = {}
            )
        }
    }
}
// 22100259 Mobile Application Development | Final Project
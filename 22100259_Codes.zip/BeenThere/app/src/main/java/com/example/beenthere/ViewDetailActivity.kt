package com.example.beenthere

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.annotation.ExperimentalCoilApi
import coil.compose.rememberImagePainter
import com.example.beenthere.ui.theme.BeenThereTheme

/**
 * Activity for viewing details of a selected cafe.
 * Allows editing and deleting of the cafe entry.
 */
class ViewDetailActivity : ComponentActivity() {

    private lateinit var dbHelper: DatabaseHelper

    private val editCafeLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val updatedCafeName = result.data?.getStringExtra("updatedCafeName")
            if (updatedCafeName != null) {
                val updatedCafe = dbHelper.getCafeByName(updatedCafeName)
                if (updatedCafe != null) {
                    val resultIntent = Intent().putExtra("updatedCafeName", updatedCafe.name)
                    setResult(RESULT_OK, resultIntent)
                    finish()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cafeName = intent.getStringExtra("cafeName") ?: ""
        dbHelper = DatabaseHelper(this)
        val cafe = dbHelper.getCafeByName(cafeName)
        setContent {
            BeenThereTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(10.dp, Color(0xFF7B7F4B)),
                    color = Color(0xFF9CAD84),
                ) {
                    if (cafe != null) {
                        CafeDetailScreen(
                            cafe = cafe,
                            onDelete = {
                                dbHelper.deleteCafe(cafe)
                                val resultIntent = Intent().putExtra("deleteCafeName", cafe.name)
                                setResult(RESULT_OK, resultIntent)
                                finish()
                            },
                            onEdit = {
                                val editIntent = Intent(this, EditCafeActivity::class.java).apply {
                                    putExtra("cafeName", cafe.name)
                                }
                                editCafeLauncher.launch(editIntent)
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Composable function to display details of a cafe.
 *
 * @param cafe The cafe object to display.
 * @param onDelete Lambda function to handle deletion of the cafe.
 * @param onEdit Lambda function to handle editing of the cafe.
 */
@OptIn(ExperimentalCoilApi::class)
@Composable
fun CafeDetailScreen(cafe: Cafe, onDelete: () -> Unit, onEdit: () -> Unit) {
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(25.dp)
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .fillMaxSize()
                .padding(bottom = 80.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = { (context as? ComponentActivity)?.finish() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            }
            Text(
                text = cafe.name,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF800000),
                fontStyle = FontStyle.Italic,
                fontSize = 35.sp
            )
            Text(
                text = "★".repeat(cafe.rating),
                fontSize = 35.sp,
                color = Color.Yellow,
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(8.dp))

            cafe.imageUri?.let {
                Image(
                    painter = rememberImagePainter(it),
                    contentDescription = null,
                    modifier = Modifier
                        .size(200.dp)
                        .align(Alignment.CenterHorizontally)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = cafe.additionalInfo,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                fontStyle = FontStyle.Italic
            )
            Spacer(modifier = Modifier.height(30.dp))

            Row {
                Text(
                    text = "Date: ${cafe.date}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Time: ${cafe.time}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
            }
        }
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .align(Alignment.BottomCenter)
        ) {
            Button(onClick = onDelete, colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)) {
                Text("DELETE", color = Color.Red, fontWeight = FontWeight.ExtraBold)
            }
            Button(onClick = onEdit, colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)) {
                Text("EDIT", color = Color.Black, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/**
 * Preview function for CafeDetailScreen.
 */
@Preview(showBackground = true)
@Composable
fun CafeDetailScreenPreview() {
    BeenThereTheme {
        val cafe = Cafe(
            name = "Cafe Mocha",
            rating = 4,
            additionalInfo = "A lovely cafe with great ambiance.",
            date = "01/08/2024",
            time = "10:30 AM",
            imageUri = ""
        )
        CafeDetailScreen(
            cafe = cafe,
            onDelete = {},
            onEdit = {}
        )
    }
}
// 22100259 Mobile Application Development | Final Project